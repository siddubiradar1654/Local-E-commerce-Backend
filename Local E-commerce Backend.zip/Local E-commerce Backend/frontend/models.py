from django.db import models

# This app will be mostly used for producing the frontend (HTML)
