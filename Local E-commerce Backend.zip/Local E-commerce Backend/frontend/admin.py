from django.contrib import admin

# This app will be mostly used for producing the frontend (HTML)